package com.ecommerce.config;

import com.ecommerce.entities.*;
import com.ecommerce.services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class DataInitializer implements CommandLineRunner {
    
    @Autowired
    private RoleService roleService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private CategoryService categoryService;
    
    @Autowired
    private ProductService productService;
    
    @Override
    public void run(String... args) throws Exception {
        initializeRoles();
        initializeUsers();
        initializeCategories();
        initializeProducts();
    }
    
    private void initializeRoles() {
        roleService.initializeRoles();
    }
    
    private void initializeUsers() {
        if (!userService.existsByUsername("admin")) {
            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword("admin123");
            admin.setEmail("admin@shop.com");
            admin.setFirstName("Admin");
            admin.setLastName("Shop");
            admin.setPhone("0601234567");
            admin.setAddress("Knez Mihailova 1");
            admin.setCity("Beograd");
            admin.setPostalCode("11000");
            admin.getRoles().add(roleService.findByName("ADMIN").get());
            userService.save(admin);
        }
        
        if (!userService.existsByUsername("manager")) {
            User manager = new User();
            manager.setUsername("manager");
            manager.setPassword("manager123");
            manager.setEmail("manager@shop.com");
            manager.setFirstName("Petar");
            manager.setLastName("Manager");
            manager.setPhone("0611234567");
            manager.setAddress("Bulevar Oslobođenja 10");
            manager.setCity("Novi Sad");
            manager.setPostalCode("21000");
            manager.getRoles().add(roleService.findByName("MANAGER").get());
            userService.save(manager);
        }
        
        if (!userService.existsByUsername("kupac1")) {
            User customer = new User();
            customer.setUsername("kupac1");
            customer.setPassword("kupac123");
            customer.setEmail("kupac1@shop.com");
            customer.setFirstName("Marija");
            customer.setLastName("Kupac");
            customer.setPhone("0621234567");
            customer.setAddress("Kralja Milana 15");
            customer.setCity("Niš");
            customer.setPostalCode("18000");
            customer.getRoles().add(roleService.findByName("CUSTOMER").get());
            userService.save(customer);
        }
    }
    
    private void initializeCategories() {
        String[] categories = {
            "Elektronika", "Odeća", "Knjige", "Sport", "Dom i bašta",
            "Igračke", "Muzika", "Film", "Auto", "Zdravlje"
        };
        
        for (String categoryName : categories) {
            if (!categoryService.existsByName(categoryName)) {
                Category category = new Category();
                category.setName(categoryName);
                category.setDescription("Opis za kategoriju " + categoryName);
                category.setActive(true);
                categoryService.save(category);
            }
        }
    }
    
    private void initializeProducts() {
        if (productService.findAll().isEmpty()) {
            Category elektronika = categoryService.searchCategories("Elektronika").get(0);
            Category odeca = categoryService.searchCategories("Odeća").get(0);
            Category knjige = categoryService.searchCategories("Knjige").get(0);
            Category sport = categoryService.searchCategories("Sport").get(0);
            Category dom = categoryService.searchCategories("Dom").get(0);
            
            // Elektronika
            Product phone1 = new Product();
            phone1.setName("iPhone 15 Pro");
            phone1.setDescription("Najnoviji iPhone model sa naprednim funkcijama");
            phone1.setPrice(new BigDecimal("140000"));
            phone1.setStockQuantity(25);
            phone1.setSku("IPH15PRO-001");
            phone1.setWeight(new BigDecimal("0.187"));
            phone1.setDimensions("146.6 x 70.6 x 7.8 mm");
            phone1.setCategory(elektronika);
            phone1.setActive(true);
            productService.save(phone1);
            
            Product laptop1 = new Product();
            laptop1.setName("MacBook Air M2");
            laptop1.setDescription("Moćan i energetski efikasan laptop");
            laptop1.setPrice(new BigDecimal("180000"));
            laptop1.setStockQuantity(15);
            laptop1.setSku("MBA-M2-001");
            laptop1.setWeight(new BigDecimal("1.24"));
            laptop1.setDimensions("304.1 x 215 x 11.3 mm");
            laptop1.setCategory(elektronika);
            laptop1.setActive(true);
            productService.save(laptop1);
            
            Product tv1 = new Product();
            tv1.setName("Samsung 55\" QLED TV");
            tv1.setDescription("4K Ultra HD Smart TV sa QLED tehnologijom");
            tv1.setPrice(new BigDecimal("85000"));
            tv1.setStockQuantity(10);
            tv1.setSku("SAM-TV55-001");
            tv1.setWeight(new BigDecimal("15.5"));
            tv1.setDimensions("1228 x 706 x 59 mm");
            tv1.setCategory(elektronika);
            tv1.setActive(true);
            productService.save(tv1);
            
            // Odeća
            Product majica1 = new Product();
            majica1.setName("Polo majica - muška");
            majica1.setDescription("Elegantna polo majica od kvalitetnog pamuka");
            majica1.setPrice(new BigDecimal("3500"));
            majica1.setStockQuantity(50);
            majica1.setSku("POLO-M-001");
            majica1.setWeight(new BigDecimal("0.25"));
            majica1.setCategory(odeca);
            majica1.setActive(true);
            productService.save(majica1);
            
            Product haljina1 = new Product();
            haljina1.setName("Letnja haljina");
            haljina1.setDescription("Lagana i udobna haljina za letnje dane");
            haljina1.setPrice(new BigDecimal("6500"));
            haljina1.setStockQuantity(30);
            haljina1.setSku("HALJINA-001");
            haljina1.setWeight(new BigDecimal("0.3"));
    haljina1.setCategory(odeca);
    haljina1.setActive(true);
    productService.save(haljina1);

    // Knjige   
    Product knjiga1 = new Product();
    knjiga1.setName("Harry Potter i Kamen mudrosti");
    knjiga1.setDescription("Prva knjiga iz serijala o Harryju Potteru.");
    knjiga1.setPrice(new BigDecimal("1200"));
    knjiga1.setStockQuantity(100);
    knjiga1.setSku("HP-KNJIGA-001");
    knjiga1.setWeight(new BigDecimal("0.5"));
    knjiga1.setCategory(knjige);
    knjiga1.setActive(true);
    productService.save(knjiga1);

    // Sport
    Product lopta1 = new Product();
    lopta1.setName("Fudbalska lopta");
    lopta1.setDescription("Profesionalna fudbalska lopta.");
    lopta1.setPrice(new BigDecimal("2500"));
    lopta1.setStockQuantity(40);
    lopta1.setSku("SPORT-LOPTA-001");
    lopta1.setWeight(new BigDecimal("0.45"));
    lopta1.setCategory(sport);
    lopta1.setActive(true);
    productService.save(lopta1);

// Dom i bašta
    Product stolica1 = new Product();
    stolica1.setName("Drvena stolica");
    stolica1.setDescription("Elegantna drvena stolica za dnevni boravak.");
    stolica1.setPrice(new BigDecimal("7500"));
    stolica1.setStockQuantity(20);
    stolica1.setSku("DOM-STOLICA-001");
    stolica1.setWeight(new BigDecimal("5.0"));
    stolica1.setCategory(dom);
    stolica1.setActive(true);
    productService.save(stolica1);