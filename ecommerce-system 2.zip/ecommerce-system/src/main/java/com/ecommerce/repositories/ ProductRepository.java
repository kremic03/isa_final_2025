package com.ecommerce.repositories;

import com.ecommerce.entities.Product;
import com.ecommerce.entities.Category;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
    
    List<Product> findByNameContainingIgnoreCase(String name);
    
    List<Product> findBySku(String sku);
    
    List<Product> findByCategory(Category category);
    
    @Query("SELECT p FROM Product p WHERE p.active = true")
    List<Product> findActiveProducts();
    
    @Query("SELECT p FROM Product p WHERE p.active = true")
    Page<Product> findActiveProducts(Pageable pageable);
    
    @Query("SELECT p FROM Product p WHERE p.active = true AND p.stockQuantity > 0")
    List<Product> findAvailableProducts();
    
    @Query("SELECT p FROM Product p WHERE p.active = true AND p.stockQuantity > 0")
    Page<Product> findAvailableProducts(Pageable pageable);
    
    @Query("SELECT p FROM Product p WHERE p.category.id = :categoryId AND p.active = true")
    List<Product> findActiveProductsByCategory(@Param("categoryId") Long categoryId);
    
    @Query("SELECT p FROM Product p WHERE p.category.id = :categoryId AND p.active = true AND p.stockQuantity > 0")
    List<Product> findAvailableProductsByCategory(@Param("categoryId") Long categoryId);
    
    @Query("SELECT p FROM Product p WHERE p.price BETWEEN :minPrice AND :maxPrice AND p.active = true")
    Page<Product> findActiveProductsByPriceRange(@Param("minPrice") BigDecimal minPrice, 
                                                @Param("maxPrice") BigDecimal maxPrice, 
                                                Pageable pageable);
    
    @Query("SELECT p FROM Product p WHERE " +
           "(LOWER(p.name) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(p.description) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(p.category.name) LIKE LOWER(CONCAT('%', :searchTerm, '%'))) " +
           "AND p.active = true")
    Page<Product> searchActiveProducts(@Param("searchTerm") String searchTerm, Pageable pageable);
    
    @Query("SELECT p FROM Product p WHERE " +
           "(LOWER(p.name) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(p.description) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(p.category.name) LIKE LOWER(CONCAT('%', :searchTerm, '%'))) " +
           "AND p.active = true AND p.stockQuantity > 0")
    Page<Product> searchAvailableProducts(@Param("searchTerm") String searchTerm, Pageable pageable);
    
    @Query("SELECT COUNT(p) FROM Product p WHERE p.active = true")
    Long countActiveProducts();
    
    @Query("SELECT COUNT(p) FROM Product p WHERE p.active = true AND p.stockQuantity > 0")
    Long countAvailableProducts();
    
    @Query("SELECT COUNT(p) FROM Product p WHERE p.active = true AND p.stockQuantity = 0")
    Long countOutOfStockProducts();
    
    @Query("SELECT p FROM Product p WHERE p.stockQuantity <= 5 AND p.active = true ORDER BY p.stockQuantity ASC")
    List<Product> findLowStockProducts();
    
    @Query("SELECT p FROM Product p ORDER BY p.createdAt DESC")
    Page<Product> findNewestProducts(Pageable pageable);
    
    @Query("SELECT p FROM Product p WHERE p.active = true ORDER BY p.createdAt DESC")
    List<Product> findLatestActiveProducts(Pageable pageable);
    
    boolean existsBySku(String sku);
    
    @Query("SELECT DISTINCT p.category FROM Product p WHERE p.active = true")
    List<Category> findDistinctCategoriesWithActiveProducts();
}

