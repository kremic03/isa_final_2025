package com.ecommerce.repositories;

import com.ecommerce.entities.Category;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Long> {
    
    List<Category> findByNameContainingIgnoreCase(String name);
    
    List<Category> findByActiveTrue();
    
    @Query("SELECT c FROM Category c WHERE c.active = true AND SIZE(c.products) > 0")
    List<Category> findActiveCategoriesWithProducts();
    
    @Query("SELECT c FROM Category c WHERE c.active = true ORDER BY SIZE(c.products) DESC")
    Page<Category> findActiveCategoriesOrderByProductCount(Pageable pageable);
    
    @Query("SELECT COUNT(p) FROM Product p WHERE p.category.id = :categoryId AND p.active = true")
    Long countActiveProductsByCategory(@Param("categoryId") Long categoryId);
    
    boolean existsByName(String name);
}