package com.ecommerce.controllers;

import com.ecommerce.services.*;
import com.ecommerce.entities.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
    
    @Autowired
    private ProductService productService;
    
    @Autowired
    private OrderService orderService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private CategoryService categoryService;
    
    @GetMapping("/")
    public String home(Model model, Authentication authentication) {
        // Dashboard statistics
        model.addAttribute("totalProducts", productService.countActiveProducts());
        model.addAttribute("availableProducts", productService.countAvailableProducts());
        model.addAttribute("outOfStockProducts", productService.countOutOfStockProducts());
        model.addAttribute("totalOrders", orderService.findAll().size());
        model.addAttribute("pendingOrders", orderService.countByStatus(Order.OrderStatus.PENDING));
        model.addAttribute("totalRevenue", orderService.getTotalRevenue());
        model.addAttribute("totalUsers", userService.findAll().size());
        model.addAttribute("totalCategories", categoryService.findActiveCategories().size());
        
        // Recent data for dashboard
        model.addAttribute("latestProducts", productService.findLatestProducts(5));
        model.addAttribute("lowStockProducts", productService.findLowStockProducts().stream().limit(5).toList());
        model.addAttribute("activeOrders", orderService.findActiveOrders().stream().limit(5).toList());
        
        return "index";
    }
    
    @GetMapping("/login")
    public String login() {
        return "auth/login";
    }
    
    @GetMapping("/access-denied")
    public String accessDenied() {
        return "error/access-denied";
    }
}
