package com.ecommerce.controllers;

import com.ecommerce.entities.Product;
import com.ecommerce.services.ProductService;
import com.ecommerce.services.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.validation.Valid;
import java.util.Optional;

@Controller
@RequestMapping("/products")
public class ProductController {
    
    @Autowired
    private ProductService productService;
    
    @Autowired
    private CategoryService categoryService;
    
    @GetMapping
    public String listProducts(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size,
            @RequestParam(defaultValue = "name") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir,
            @RequestParam(required = false) String search,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) Boolean availableOnly,
            Model model) {
        
        Sort sort = sortDir.equals("desc") ? Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<Product> productPage;
        if (search != null && !search.trim().isEmpty()) {
            if (availableOnly != null && availableOnly) {
                productPage = productService.searchAvailableProducts(search, pageable);
            } else {
                productPage = productService.searchActiveProducts(search, pageable);
            }
            model.addAttribute("search", search);
        } else if (categoryId != null) {
            // Filter by category - would need custom repository method
            productPage = productService.findActiveProducts(pageable);
            model.addAttribute("categoryId", categoryId);
        } else if (availableOnly != null && availableOnly) {
            productPage = productService.findAvailableProducts(pageable);
        } else {
            productPage = productService.findActiveProducts(pageable);
        }
        
        model.addAttribute("productPage", productPage);
        model.addAttribute("sortBy", sortBy);
        model.addAttribute("sortDir", sortDir);
        model.addAttribute("reverseSortDir", sortDir.equals("asc") ? "desc" : "asc");
        model.addAttribute("availableOnly", availableOnly);
        model.addAttribute("categories", categoryService.findActiveCategoriesWithProducts());
        
        return "products/list";
    }
    
    @GetMapping("/new")
    @PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER')")
    public String showCreateForm(Model model) {
        model.addAttribute("product", new Product());
        model.addAttribute("categories", categoryService.findActiveCategories());
        return "products/form";
    }
    
    @GetMapping("/{id}")
    public String showProduct(@PathVariable Long id, Model model) {
        Optional<Product> product = productService.findById(id);
        if (product.isPresent()) {
            model.addAttribute("product", product.get());
            // Related products from same category
            model.addAttribute("relatedProducts", 
                productService.findAvailableProductsByCategory(product.get().getCategory().getId())
                    .stream().filter(p -> !p.getId().equals(id)).limit(4).toList());
            return "products/detail";
        }
        return "redirect:/products";
    }
    
    @GetMapping("/{id}/edit")
    @PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER')")
    public String showEditForm(@PathVariable Long id, Model model) {
        Optional<Product> product = productService.findById(id);
        if (product.isPresent()) {
            model.addAttribute("product", product.get());
            model.addAttribute("categories", categoryService.findActiveCategories());
            return "products/form";
        }
        return "redirect:/products";
    }
    
    @PostMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER')")
    public String saveProduct(@Valid @ModelAttribute Product product, BindingResult result, 
                            Model model, RedirectAttributes redirectAttributes) {
        
        if (product.getId() == null && product.getSku() != null && productService.existsBySku(product.getSku())) {
            result.rejectValue("sku", "error.product", "Product with this SKU already exists");
        }
        
        if (result.hasErrors()) {
            model.addAttribute("categories", categoryService.findActiveCategories());
            return "products/form";
        }
        
        try {
            productService.save(product);
            redirectAttributes.addFlashAttribute("successMessage", 
                product.getId() == null ? "Product created successfully!" : "Product updated successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error saving product: " + e.getMessage());
        }
        
        return "redirect:/products";
    }
    
    @PostMapping("/{id}/delete")
    @PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER')")
    public String deleteProduct(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            productService.deleteById(id);
            redirectAttributes.addFlashAttribute("successMessage", "Product deleted successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error deleting product: " + e.getMessage());
        }
        return "redirect:/products";
    }
    
    @PostMapping("/{id}/toggle-status")
    @PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER')")
    public String toggleProductStatus(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            productService.toggleProductStatus(id);
            redirectAttributes.addFlashAttribute("successMessage", "Product status updated!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error updating product status: " + e.getMessage());
        }
        return "redirect:/products";
    }
    
    @PostMapping("/{id}/update-stock")
    @PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER')")
    public String updateStock(@PathVariable Long id, @RequestParam Integer stockQuantity,
                            RedirectAttributes redirectAttributes) {
        try {
            productService.updateStock(id, stockQuantity);
            redirectAttributes.addFlashAttribute("successMessage", "Stock updated successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error updating stock: " + e.getMessage());
        }
        return "redirect:/products/" + id;
    }
}
