package com.ecommerce.services;

import com.ecommerce.entities.Order;
import com.ecommerce.entities.OrderItem;
import com.ecommerce.entities.User;
import com.ecommerce.entities.Product;
import com.ecommerce.repositories.OrderRepository;
import com.ecommerce.repositories.OrderItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class OrderService {
    
    @Autowired
    private OrderRepository orderRepository;
    
    @Autowired
    private OrderItemRepository orderItemRepository;
    
    @Autowired
    private ProductService productService;
    
    public List<Order> findAll() {
        return orderRepository.findAll();
    }
    
    public Page<Order> findAll(Pageable pageable) {
        return orderRepository.findAll(pageable);
    }
    
    public Optional<Order> findById(Long id) {
        return orderRepository.findById(id);
    }
    
    public Optional<Order> findByOrderNumber(String orderNumber) {
        return orderRepository.findByOrderNumber(orderNumber);
    }
    
    public List<Order> findByUser(User user) {
        return orderRepository.findByUser(user);
    }
    
    public Page<Order> findByUser(Long userId, Pageable pageable) {
        return orderRepository.findByUser(userId, pageable);
    }
    
    public Page<Order> findByStatus(Order.OrderStatus status, Pageable pageable) {
        return orderRepository.findByStatus(status, pageable);
    }
    
    public Page<Order> searchOrders(String searchTerm, Pageable pageable) {
        return orderRepository.searchOrders(searchTerm, pageable);
    }
    
    public List<Order> findActiveOrders() {
        return orderRepository.findActiveOrders();
    }
    
    public Page<Order> findActiveOrders(Pageable pageable) {
        return orderRepository.findActiveOrders(pageable);
    }
    
    public Order createOrder(User user, List<OrderItem> items, String shippingAddress, 
                           Order.PaymentMethod paymentMethod, String notes) {
        Order order = new Order();
        order.setOrderNumber(generateOrderNumber());
        order.setUser(user);
        order.setShippingAddress(shippingAddress);
        order.setBillingAddress(shippingAddress); // Default billing = shipping
        order.setPaymentMethod(paymentMethod);
        order.setNotes(notes);
        order.setStatus(Order.OrderStatus.PENDING);
        
        // Calculate totals
        BigDecimal subtotal = BigDecimal.ZERO;
        for (OrderItem item : items) {
            item.setOrder(order);
            item.calculateTotalPrice();
            subtotal = subtotal.add(item.getTotalPrice());
            
            // Reduce product stock
            productService.reduceStock(item.getProduct().getId(), item.getQuantity());
        }
        
        order.setShippingCost(calculateShippingCost(subtotal));
        order.setTaxAmount(calculateTax(subtotal));
        order.setTotalAmount(subtotal.add(order.getShippingCost()).add(order.getTaxAmount()));
        
        order.getOrderItems().addAll(items);
        return orderRepository.save(order);
    }
    
    public Order updateOrderStatus(Long orderId, Order.OrderStatus newStatus) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        
        Order.OrderStatus oldStatus = order.getStatus();
        order.setStatus(newStatus);
        
        // Set timestamps based on status
        switch (newStatus) {
            case SHIPPED:
                order.setShippedDate(LocalDateTime.now());
                break;
            case DELIVERED:
                order.setDeliveredDate(LocalDateTime.now());
                break;
            case CANCELLED:
                // Return stock for cancelled orders
                if (oldStatus == Order.OrderStatus.PENDING || oldStatus == Order.OrderStatus.CONFIRMED) {
                    returnStockForOrder(order);
                }
                break;
        }
        
        return orderRepository.save(order);
    }
    
    public Order confirmOrder(Long orderId) {
        return updateOrderStatus(orderId, Order.OrderStatus.CONFIRMED);
    }
    
    public Order shipOrder(Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        
        if (!order.canBeShipped()) {
            throw new RuntimeException("Order cannot be shipped in current status");
        }
        
        return updateOrderStatus(orderId, Order.OrderStatus.SHIPPED);
    }
    
    public Order deliverOrder(Long orderId) {
        return updateOrderStatus(orderId, Order.OrderStatus.DELIVERED);
    }
    
    public Order cancelOrder(Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        
        if (!order.canBeCancelled()) {
            throw new RuntimeException("Order cannot be cancelled in current status");
        }
        
        return updateOrderStatus(orderId, Order.OrderStatus.CANCELLED);
    }
    
    public void deleteById(Long id) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        
        // Return stock if order was not delivered
        if (order.getStatus() != Order.OrderStatus.DELIVERED && order.getStatus() != Order.OrderStatus.CANCELLED) {
            returnStockForOrder(order);
        }
        
        orderRepository.deleteById(id);
    }
    
    public Long countByStatus(Order.OrderStatus status) {
        return orderRepository.countByStatus(status);
    }
    
    public BigDecimal getTotalRevenue() {
        BigDecimal revenue = orderRepository.getTotalRevenue();
        return revenue != null ? revenue : BigDecimal.ZERO;
    }
    
    public BigDecimal getRevenueForPeriod(LocalDateTime startDate, LocalDateTime endDate) {
        BigDecimal revenue = orderRepository.getRevenueForPeriod(startDate, endDate);
        return revenue != null ? revenue : BigDecimal.ZERO;
    }
    
    private void returnStockForOrder(Order order) {
        for (OrderItem item : order.getOrderItems()) {
            productService.increaseStock(item.getProduct().getId(), item.getQuantity());
        }
    }
    
    private String generateOrderNumber() {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        String randomSuffix = String.valueOf((int)(Math.random() * 1000));
        return "ORD-" + timestamp + "-" + String.format("%03d", Integer.parseInt(randomSuffix));
    }
    
    private BigDecimal calculateShippingCost(BigDecimal subtotal) {
        // Free shipping over 5000 RSD
        if (subtotal.compareTo(new BigDecimal("5000")) >= 0) {
            return BigDecimal.ZERO;
        }
        return new BigDecimal("300"); // 300 RSD shipping
    }
    
    private BigDecimal calculateTax(BigDecimal subtotal) {
        // 20% VAT
        return subtotal.multiply(new BigDecimal("0.20"));
    }
}
