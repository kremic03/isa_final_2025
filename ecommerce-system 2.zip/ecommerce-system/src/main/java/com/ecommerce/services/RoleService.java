package com.ecommerce.services;

import com.ecommerce.entities.Role;
import com.ecommerce.repositories.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class RoleService {
    
    @Autowired
    private RoleRepository roleRepository;
    
    public List<Role> findAll() {
        return roleRepository.findAll();
    }
    
    public Optional<Role> findById(Long id) {
        return roleRepository.findById(id);
    }
    
    public Optional<Role> findByName(String name) {
        return roleRepository.findByName(name);
    }
    
    public Role save(Role role) {
        if (roleRepository.existsByName(role.getName()) && role.getId() == null) {
            throw new RuntimeException("Role with this name already exists");
        }
        return roleRepository.save(role);
    }
    
    public void deleteById(Long id) {
        roleRepository.deleteById(id);
    }
    
    public boolean existsByName(String name) {
        return roleRepository.existsByName(name);
    }
    
    public void initializeRoles() {
        if (!roleRepository.existsByName("ADMIN")) {
            Role adminRole = new Role("ADMIN", "Administrator with full access");
            roleRepository.save(adminRole);
        }
        
        if (!roleRepository.existsByName("MANAGER")) {
            Role managerRole = new Role("MANAGER", "Sales manager with product and order management access");
            roleRepository.save(managerRole);
        }
        
        if (!roleRepository.existsByName("CUSTOMER")) {
            Role customerRole = new Role("CUSTOMER", "Customer with shopping access");
            roleRepository.save(customerRole);
        }
    }
}