package com.ecommerce.services;

import com.ecommerce.entities.Category;
import com.ecommerce.repositories.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class CategoryService {
    
    @Autowired
    private CategoryRepository categoryRepository;
    
    public List<Category> findAll() {
        return categoryRepository.findAll();
    }
    
    public Page<Category> findAll(Pageable pageable) {
        return categoryRepository.findAll(pageable);
    }
    
    public List<Category> findActiveCategories() {
        return categoryRepository.findByActiveTrue();
    }
    
    public List<Category> findActiveCategoriesWithProducts() {
        return categoryRepository.findActiveCategoriesWithProducts();
    }
    
    public Optional<Category> findById(Long id) {
        return categoryRepository.findById(id);
    }
    
    public List<Category> searchCategories(String name) {
        return categoryRepository.findByNameContainingIgnoreCase(name);
    }
    
    public Category save(Category category) {
        if (categoryRepository.existsByName(category.getName()) && category.getId() == null) {
            throw new RuntimeException("Category with this name already exists");
        }
        return categoryRepository.save(category);
    }
    
    public void deleteById(Long id) {
        Optional<Category> category = categoryRepository.findById(id);
        if (category.isPresent()) {
            Long productCount = categoryRepository.countActiveProductsByCategory(id);
            if (productCount > 0) {
                throw new RuntimeException("Cannot delete category with existing products");
            }
            categoryRepository.deleteById(id);
        }
    }
    
    public Long countActiveProductsByCategory(Long categoryId) {
        return categoryRepository.countActiveProductsByCategory(categoryId);
    }
    
    public boolean existsByName(String name) {
        return categoryRepository.existsByName(name);
    }
    
    public void toggleCategoryStatus(Long id) {
        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Category not found"));
        category.setActive(!category.getActive());
        categoryRepository.save(category);
    }
}
