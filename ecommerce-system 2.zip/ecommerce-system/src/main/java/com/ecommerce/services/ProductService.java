package com.ecommerce.services;

import com.ecommerce.entities.Product;
import com.ecommerce.entities.Category;
import com.ecommerce.repositories.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@Transactional
public class ProductService {
    
    @Autowired
    private ProductRepository productRepository;
    
    public List<Product> findAll() {
        return productRepository.findAll();
    }
    
    public Page<Product> findAll(Pageable pageable) {
        return productRepository.findAll(pageable);
    }
    
    public List<Product> findActiveProducts() {
        return productRepository.findActiveProducts();
    }
    
    public Page<Product> findActiveProducts(Pageable pageable) {
        return productRepository.findActiveProducts(pageable);
    }
    
    public List<Product> findAvailableProducts() {
        return productRepository.findAvailableProducts();
    }
    
    public Page<Product> findAvailableProducts(Pageable pageable) {
        return productRepository.findAvailableProducts(pageable);
    }
    
    public Optional<Product> findById(Long id) {
        return productRepository.findById(id);
    }
    
    public List<Product> searchProducts(String name) {
        return productRepository.findByNameContainingIgnoreCase(name);
    }
    
    public Page<Product> searchActiveProducts(String searchTerm, Pageable pageable) {
        return productRepository.searchActiveProducts(searchTerm, pageable);
    }
    
    public Page<Product> searchAvailableProducts(String searchTerm, Pageable pageable) {
        return productRepository.searchAvailableProducts(searchTerm, pageable);
    }
    
    public List<Product> findByCategory(Category category) {
        return productRepository.findByCategory(category);
    }
    
    public List<Product> findActiveProductsByCategory(Long categoryId) {
        return productRepository.findActiveProductsByCategory(categoryId);
    }
    
    public List<Product> findAvailableProductsByCategory(Long categoryId) {
        return productRepository.findAvailableProductsByCategory(categoryId);
    }
    
    public Page<Product> findByPriceRange(BigDecimal minPrice, BigDecimal maxPrice, Pageable pageable) {
        return productRepository.findActiveProductsByPriceRange(minPrice, maxPrice, pageable);
    }
    
    public List<Product> findLowStockProducts() {
        return productRepository.findLowStockProducts();
    }
    
    public List<Product> findLatestProducts(int limit) {
        return productRepository.findLatestActiveProducts(PageRequest.of(0, limit));
    }
    
    public Product save(Product product) {
        if (product.getSku() == null || product.getSku().trim().isEmpty()) {
            product.setSku(generateSku());
        }
        
        if (product.getSku() != null && productRepository.existsBySku(product.getSku()) && product.getId() == null) {
            throw new RuntimeException("Product with this SKU already exists");
        }
        
        return productRepository.save(product);
    }
    
    public void deleteById(Long id) {
        productRepository.deleteById(id);
    }
    
    public boolean existsBySku(String sku) {
        return productRepository.existsBySku(sku);
    }
    
    public Long countActiveProducts() {
        return productRepository.countActiveProducts();
    }
    
    public Long countAvailableProducts() {
        return productRepository.countAvailableProducts();
    }
    
    public Long countOutOfStockProducts() {
        return productRepository.countOutOfStockProducts();
    }
    
    public void updateStock(Long productId, Integer newStockQuantity) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        product.setStockQuantity(newStockQuantity);
        productRepository.save(product);
    }
    
    public void reduceStock(Long productId, Integer quantity) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        product.reduceStock(quantity);
        productRepository.save(product);
    }
    
    public void increaseStock(Long productId, Integer quantity) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        product.increaseStock(quantity);
        productRepository.save(product);
    }
    
    public void toggleProductStatus(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        product.setActive(!product.getActive());
        productRepository.save(product);
    }
    
    private String generateSku() {
        return "PRD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }
}
